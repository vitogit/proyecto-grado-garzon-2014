#ifndef INC_REQ_newGA
#define INC_REQ_newGA
#include "newGA.hh"
#include <math.h>

skeleton newGA
{

	// Problem ---------------------------------------------------------------

	Problem::Problem () {
            //Este es el largo del genoma
            _largo_cromosoma = LARGO_CROMOSOMA  ;
            cruces = new int[CANTIDAD_CRUCES];
            // se obtiene el directorio principal
            char arrayPath[FILENAME_MAX];
            if (!getcwd(arrayPath, FILENAME_MAX)) {
                cout << "Error: No se encontró el directorio." << endl;
            }
            else  {
               path = arrayPath;
               pathSemaforos = path + SEMAFOROS;
               pathTemplate = path + TEMPLATE_SEMAFOROS;
               pathGarzon = path + GARZON;
               pathMejorConfiguracionSemaforos = path + MEJOR_CONFIGURACION_SERMAFOROS;
               pathOut = path + OUT;
               pathSalidaSumo = path + SALIDA_SUMO;
               pathSalidaTrip = path + SALIDA_TRIP;
               pathBusFlowXml = path + BUSFLOW_XML;
               sumo = SUMO;
               sumo = sumo + " -c " + pathGarzon;
               sumo = sumo + " -a " + pathSemaforos +","+pathBusFlowXml;
               sumo = sumo + " -l " + pathOut;
               sumo = sumo + " --no-step-log";
               sumo = sumo + " --no-warnings";
               sumo = sumo + " --tripinfo-output "+pathSalidaTrip;
               sumo = sumo + " -e " + DURACION_SIMULACION;
               //sumo = sumo + " --vehroute-output output_vehroute.xml";

               //sumo = sumo + " --summary output_summary.xml";
               sumo = sumo + " > " + pathSalidaSumo;

            }
	}

	ostream& operator<< (ostream& os, const Problem& pbm)
	{
		/*os << endl << endl << "Number of Variables " << pbm._largo_cromosoma
		   << endl;
		return os;*/
                
	}

	istream& operator>> (istream& is, Problem& pbm)
	{
		/*char buffer[MAX_BUFFER];
		int i;

		is.getline(buffer,MAX_BUFFER,'\n');
		sscanf(buffer,"%d",&pbm._largo_cromosoma);

		return is;*/
	}

	bool Problem::operator== (const Problem& pbm) const
	{
		/*if (_largo_cromosoma!=pbm.largo_cromosoma()) return false;
		return true;*/
	}

	bool Problem::operator!= (const Problem& pbm) const
	{
		return !(*this == pbm);
	}

	Direction Problem::direction() const
	{
		return maximize;
		//return minimize;
	}

	int Problem::largo_cromosoma() const
	{
		return _largo_cromosoma;
	}

	Problem::~Problem()
	{
            delete [] cruces;
	}

	// Solution --------------------------------------------------------------

	Solution::Solution (const Problem& pbm): _pbm(pbm), _var(pbm.largo_cromosoma()),_current_fitness(infinity())	{}

        double Solution::current_fitness()
        {
            return _current_fitness;
        }
        
	const Problem& Solution::pbm() const
	{
		return _pbm;
	}

	Solution::Solution(const Solution& sol):_pbm(sol.pbm())
	{
		*this=sol;
	}

	istream& operator>> (istream& is, Solution& sol)
	{
		for (int i=0;i<sol.pbm().largo_cromosoma();i++)
			is >> sol._var[i];
		return is;
	}

	ostream& operator<< (ostream& os, const Solution& sol)
	{
		for (int i=0;i<sol.pbm().largo_cromosoma();i++)
			os << " " << sol._var[i];
		return os;
	}

	NetStream& operator << (NetStream& ns, const Solution& sol)
	{
		for (int i=0;i<sol._var.size();i++)
			ns << sol._var[i];
		return ns;
	}

	NetStream& operator >> (NetStream& ns, Solution& sol)
	{
		for (int i=0;i<sol._var.size();i++)
			ns >> sol._var[i];
		return ns;
	}

 	Solution& Solution::operator= (const Solution &sol)
	{
		_var=sol._var;
		return *this;
	}

	bool Solution::operator== (const Solution& sol) const
	{
		if (sol.pbm() != _pbm) return false;
		for(int i = 0; i < _var.size(); i++)
			if(_var[i] != sol._var[i]) return false;
		return true;
	}

	bool Solution::operator!= (const Solution& sol) const
	{
		return !(*this == sol);
	}

        
	void Solution::initialize()
	{

            // inicialización de las cantidades de los cruces
            for(int numeroCruce = 0; numeroCruce < CANTIDAD_CRUCES; numeroCruce++)
                _pbm.cruces[numeroCruce] = 0;

            //GA1DArrayGenome<int> &genoma = (GA1DArrayGenome<int> &)g;
            xml_document doc;
            doc.load_file(_pbm.pathTemplate.c_str());

            xml_node add = doc.child("add");

            int numeroCruce = 0;
            int numeroGen = 0;


            for (xml_node tlLogic = add.first_child(); tlLogic; tlLogic = tlLogic.next_sibling())
            {
                for (xml_node phase = tlLogic.first_child();phase; phase = phase.next_sibling())
                {

                    xml_attribute attr = phase.attribute("state");
                    string estado = attr.value();
                    //cout <<"estado___ " << estado << endl;

                    attr = phase.attribute("duration");
                    //cout <<"attr__ " << attr << endl;

                    int duracion = atoi(attr.value());
                    //cout <<"duracion__ " << duracion << endl;

                    if (estado.find("y") != string::npos) {
                        // Tiene una luz amarilla. la salteo
                    }
                    else
                    {                       
                        int nuevaDuracion;
                        if (rand_int(0,1)) {
                            nuevaDuracion = duracion + rand_int(0, COTA_SUMA);
                        }
                        else {
                            nuevaDuracion = duracion - rand_int(0, COTA_SUMA);                            
                        }

                        if ((COTA_MINIMA_DURACION <= nuevaDuracion) && (nuevaDuracion <= COTA_MAXIMA_DURACION))
                            _var[numeroGen] = nuevaDuracion;
                        else {
                            _var[numeroGen] = duracion;                    
                        }                        

                        numeroGen++;
                        _pbm.cruces[numeroCruce]++;
                    }
                }

                //-- gen del comienzo de fase

                _var[numeroGen] =  rand_int(0,((_pbm.cruces[numeroCruce] * 2) - 1));

                numeroGen++;
                numeroCruce++;
            }
	}

	double Solution::fitness (int id_thread)	{

            float pesoBus = 2;
            float pesoCar = 1;
            //cout << "Arranca el objective__"<<endl;

            xml_document doc;
            if (!doc.load_file(_pbm.pathTemplate.c_str())) return -1;

            xml_node add = doc.child("add");

            int indiceGen = 0;

            for (pugi::xml_node tlLogic = add.first_child(); tlLogic; tlLogic = tlLogic.next_sibling()) {
                for (pugi::xml_node phase = tlLogic.first_child();phase; phase = phase.next_sibling()) {

                    xml_attribute state = phase.attribute("state");
                    string estado = state.value();

                    if (estado.find("y") != string::npos){
                        // Tiene una luz amarilla .la salteo
                    }
                    else {
                        // seteo la duracción
                        pugi::xml_attribute attr = phase.attribute("duration");
                        attr.set_value(_var[indiceGen] );
                        //cout <<  "attr.value: " << attr.value() <<endl; 
                        indiceGen++;
                    }
                  }
                  pugi::xml_attribute attr = tlLogic.attribute("offset");
                  attr.set_value(_var[indiceGen] );
                  indiceGen++;
            }

            // creo un archivo de semaforos por cada thread, agrego el idthread al path generico
            char nuevo_archivo[256];
            sprintf(nuevo_archivo, _pbm.pathSemaforos.c_str(),id_thread);

            ofstream salida(nuevo_archivo);
            if (salida.is_open()) {
                doc.save(salida);
                salida.close();
            }

            char nuevo_pathTripInfo[512];
            sprintf(nuevo_pathTripInfo, _pbm.pathSalidaTrip.c_str(),id_thread);            
            
            char nueva_salida_sumo[1024];
            sprintf(nueva_salida_sumo, _pbm.sumo.c_str(),id_thread,id_thread,id_thread,id_thread);
            
            
            //cout<< "nuevo_pathTripInfo_____" << nuevo_pathTripInfo <<endl;
            //cout<< "nuevosalidasumo_____" << nueva_salida_sumo <<endl;
            // llamada al simulador de tráfico
            system(nueva_salida_sumo);


            //****************

           //PARSEO DEL TRIP INFO
            xml_document doc2;
            if (!doc2.load_file(nuevo_pathTripInfo)) return -1;

            xml_node tripinfos = doc2.child("tripinfos");           
            float totalBusSpeed = 0;
            int totalBusses = 0;
            
            float totalCarSpeed = 0;
            int totalCars = 0;

            float busAverageSpeed = 0;
            float carAverageSpeed = 0;
            
            for (pugi::xml_node tripinfo = tripinfos.first_child(); tripinfo; tripinfo = tripinfo.next_sibling()) {

                    string vType = tripinfo.attribute("vType").value();
                    float routeLength = tripinfo.attribute("routeLength").as_float();
                    float duration = tripinfo.attribute("duration").as_float();
                    float speed = (routeLength/duration);

                    //The number of steps in which the vehicle speed was below 0.1m/s 
                    //float waitSteps = tripinfo.attribute("waitSteps").as_float();
 
                    if (vType == "BUS") {
                        totalBusSpeed += speed;
                        totalBusses++;
                    } else {
                        totalCarSpeed += speed;
                        totalCars++;
                    }
            }      
            
            if (totalBusses != 0){
                busAverageSpeed = totalBusSpeed/ totalBusses;
            }
            if (totalCars != 0){
                carAverageSpeed = totalCarSpeed/totalCars;
            }
            
            float fitnessValue = pesoBus * busAverageSpeed + pesoCar *carAverageSpeed;
            cout<< "Busaverage: "<< busAverageSpeed << " CarAverage: " <<carAverageSpeed << " fitnessValue: " << fitnessValue<<endl;

	    //*********
           
            char nueva_path_out[1024];
            sprintf(nueva_path_out, _pbm.pathOut.c_str(),id_thread);
            

            string line;
            ifstream streamPathOut(nueva_path_out);
            float simulationTime;
            float vehiculesEmitted = 0;
            float vehiculesRunning = 0;
            
            if (streamPathOut.is_open()) {
                while (streamPathOut.good()) {
                    getline(streamPathOut, line);
                    if (line.find("Simulation ended at time: ") != string::npos) {
                        simulationTime = atof(line.substr(26).c_str());
                    }  
                    if (line.find(" Emitted: ") != string::npos) {
                        vehiculesEmitted = atof(line.substr(10).c_str());
                    }                    
                    if (line.find(" Running: ") != string::npos) {
                        vehiculesRunning = atof(line.substr(10).c_str());
                    }  
                }
                    
                //Buscamos mas de 80% de vehiculos que finalizaron. ESto nos da el porcentaje
                if (vehiculesEmitted > 0) {
                    float vehiculesCompleted = ((vehiculesEmitted-vehiculesRunning)*100)/vehiculesEmitted;
                    cout << "emmited:" <<vehiculesEmitted << "running: " <<vehiculesRunning << "completado:" <<vehiculesCompleted<< endl;
                }                
                if (streamPathOut.is_open()){
                    streamPathOut.close();                    
                }
            } else {
                //cout << "Error abriendo archivo";
            }
            
            char remove_path[1024];
            sprintf(remove_path, "rm %s",nueva_path_out); 
            
            //cout<<"removepath _____"<< remove_path << endl;
            system(remove_path);


            //cout << "tiempo final" << simulationTime <<endl ;
            _current_fitness = fitnessValue;
            return _current_fitness;

	}

	char *Solution::to_String() const
	{
            	static char *cad = NULL;

		if(cad != NULL) delete [] cad;

		cad = new char[size()];
		if(cad == NULL) show_message(7);

		int *aux = (int *)cad;
		int n = _pbm.largo_cromosoma();

		if(!aux) show_message(7);

		for(int i = 0; i < n; i++){
		 	aux[i] = _var[i];
		}
                return cad;
              

	}

	void Solution::to_Solution(char *_string_)
	{
		int *ptr=(int *)_string_;
		for (int i=0;i<_pbm.largo_cromosoma();i++)
		{
			_var[i]=*ptr;
			ptr++;
		}
	}

	unsigned int Solution::size() const
	{
		return (_pbm.largo_cromosoma() * sizeof(int));
	}
        void  Solution::guardarEnArchivo()
        {
            xml_document doc;
            doc.load_file(_pbm.pathTemplate.c_str());

            xml_node add = doc.child("add");

            int indiceGen = 0;

            for (pugi::xml_node tlLogic = add.first_child(); tlLogic; tlLogic = tlLogic.next_sibling())
            {
                for (pugi::xml_node phase = tlLogic.first_child();phase; phase = phase.next_sibling())
                {

                    xml_attribute state = phase.attribute("state");
                    string estado = state.value();

                    if (estado.find("y") != string::npos)
                    {
                                        // Tiene una luz amarilla
                                        // la salteo
                                }
                                else
                                {
                        // el primer atributo es la duracción
                        pugi::xml_attribute attr = phase.attribute("duration");
                        attr.set_value(_var[indiceGen] );
                        indiceGen++;
                                }
                  }
                  //+
                  //******************************
                  // aca cambia el orden de las fases aque se setearon arriba
                  pugi::xml_attribute attr = tlLogic.attribute("offset");
                  attr.set_value(_var[indiceGen] );
                  indiceGen++;
                  //******************************
                  //-
            }

            // se sobreescribe el archivo
            ofstream salida(_pbm.pathMejorConfiguracionSemaforos.c_str());
                if (salida.is_open())
                {
                        doc.save(salida);
                        salida.close();
                        cout << "Se guardo la mejor configuracion" << endl;
                }
        }

        

	int& Solution::var(const int index)
	{
		return _var[index];
	}


	Rarray<int>& Solution::array_var()
	{
		return _var;
	}

	Solution::~Solution()
	{}

	// UserStatistics -------------------------------------------------------

	UserStatistics::UserStatistics ()
	{}

	ostream& operator<< (ostream& os, const UserStatistics& userstat)
	{
		os << "\n---------------------------------------------------------------" << endl;
		os << "                   STATISTICS OF TRIALS                   	 " << endl;
		os << "------------------------------------------------------------------" << endl;

		for (int i=0;i< userstat.result_trials.size();i++)
		{
			os << endl
			   << userstat.result_trials[i].trial
			   << "\t" << userstat.result_trials[i].best_cost_trial
			   << "\t\t" << userstat.result_trials[i].worst_cost_trial
			   << "\t\t\t" << userstat.result_trials[i].nb_evaluation_best_found_trial
			   << "\t\t\t" << userstat.result_trials[i].nb_iteration_best_found_trial
			   << "\t\t\t" << userstat.result_trials[i].time_best_found_trial
			   << "\t\t" << userstat.result_trials[i].time_spent_trial;
		}
		os << endl << "------------------------------------------------------------------" << endl;
		return os;
	}

	UserStatistics& UserStatistics::operator= (const UserStatistics& userstats)
	{
		result_trials=userstats.result_trials;
		return (*this);
	}

	void UserStatistics::update(const Solver& solver)
	{
		if( (solver.pid()!=0) || (solver.end_trial()!=true)
		  || ((solver.current_iteration()!=solver.setup().nb_evolution_steps())
		       && !terminateQ(solver.pbm(),solver,solver.setup())))
			return;

		struct user_stat *new_stat;

		if ((new_stat=(struct user_stat *)malloc(sizeof(struct user_stat)))==NULL)
			show_message(7);
		new_stat->trial         		 		 = solver.current_trial();
		new_stat->nb_evaluation_best_found_trial = solver.evaluations_best_found_in_trial();
		new_stat->nb_iteration_best_found_trial  = solver.iteration_best_found_in_trial();
		new_stat->worst_cost_trial     		 	 = solver.worst_cost_trial();
		new_stat->best_cost_trial     		 	 = solver.best_cost_trial();
		new_stat->time_best_found_trial		 	 = solver.time_best_found_trial();
		new_stat->time_spent_trial 		 		 = solver.time_spent_trial();

		result_trials.append(*new_stat);
	}

	void UserStatistics::clear()
	{
		result_trials.remove();
	}

	UserStatistics::~UserStatistics()
	{
		result_trials.remove();
	}

// Intra_operator  --------------------------------------------------------------

	Intra_Operator::Intra_Operator(const unsigned int _number_op):_number_operator(_number_op),probability(NULL)
	{}

	unsigned int Intra_Operator::number_operator() const
	{
		return _number_operator;
	}

	Intra_Operator *Intra_Operator::create(const unsigned int _number_op)
	{
		switch (_number_op)
		{
			case 0: return new Crossover;break;
			case 1: return new Mutation();break;
		}
	}

	ostream& operator<< (ostream& os, const Intra_Operator& intra)
	{
		switch (intra.number_operator())
		{
			case 0: os << (Crossover&)intra;break;
			case 1: os << (Mutation&)intra;break;
		}
		return os;
	}

	Intra_Operator::~Intra_Operator()
	{}

//  Crossover:Intra_operator -------------------------------------------------------------

	Crossover::Crossover():Intra_Operator(0)
	{
		probability = new float[1];
	}

	void Crossover::cross(Solution& mom,Solution& dad) const // dadas dos soluciones de la poblacion, las cruza
	{

		Solution sis = mom;
		Solution bro = dad;


        //cout << "Arranca el cruzamiento__"<<endl;

        int corte = rand_int(0,CANTIDAD_CRUCES -1);
        bool orden = rand_int(0,1);
        int indiceGen = 0;

        for(int i=0; i<CANTIDAD_CRUCES; i++)
        {
            if (i <= corte) // estoy a la izquierda del corte
            {
                for(int j=0; j<mom.pbm().cruces[i]; j++)
                {
                    if (orden)
                    {
                        sis.var(indiceGen) =  mom.var(indiceGen);
                        bro.var(indiceGen) =  dad.var(indiceGen);
                    }
                    else
                    {
                        sis.var(indiceGen) =  dad.var(indiceGen);
                        bro.var(indiceGen) =  mom.var(indiceGen);
                    }

                    indiceGen++;
                }
                // gen de inicio de fase
                if (orden)
                {
                    sis.var(indiceGen) =  mom.var(indiceGen);
                    bro.var(indiceGen) =  dad.var(indiceGen);
                }
                else
                {
                    sis.var(indiceGen) =  dad.var(indiceGen);
                    bro.var(indiceGen) =  mom.var(indiceGen);
                }
                indiceGen++;
            }
            else
            {
                for(int j=0; j<mom.pbm().cruces[i]; j++)
                {
                    if (orden)
                    {
                        sis.var(indiceGen) =  dad.var(indiceGen);
                        bro.var(indiceGen) =  mom.var(indiceGen);
                    }
                    else
                    {
                        sis.var(indiceGen) =  mom.var(indiceGen);
                        bro.var(indiceGen) =  dad.var(indiceGen);
                    }
                    indiceGen++;
                }
                // gen de inicio de fase
                if (orden)
                {
                     sis.var(indiceGen) =  dad.var(indiceGen);
                     bro.var(indiceGen) =  mom.var(indiceGen);
                }
                else
                {
                    sis.var(indiceGen) =  mom.var(indiceGen);
                    bro.var(indiceGen) =  dad.var(indiceGen);
                }
                indiceGen++;
            }

        }

        //Esto imprime bien pq el operador << esta sobrecargado en solution
        //cout<<"sis: " <<sis << endl;
        //cout<<"mom: " <<  mom<<endl;

        //cout<<"bro: "<< bro << endl;
        //cout<<"dad: " << dad <<endl;

        mom = sis;
        dad = bro;
	}

	void Crossover::execute(Rarray<Solution*>& sols) const
	{
		for (int i=0;i+1<sols.size();i=i+2)
		 	if (rand01()<=probability[0]) cross(*sols[i],*sols[i+1]);
	}

	ostream& operator<< (ostream& os, const Crossover&  cross)
	{
		 os << "Crossover." << " Probability: "
                    << cross.probability[0]
		    << endl;
		 return os;
	}

	void Crossover::RefreshState(const StateCenter& _sc) const
	{
		_sc.set_contents_state_variable("_crossover_probability",(char *)probability,1,sizeof(float));
	}

	void Crossover::UpdateFromState(const StateCenter& _sc)
	{
		 unsigned long nbytes,length;
		 _sc.get_contents_state_variable("_crossover_probability",(char *)probability,nbytes,length);
	}

	void Crossover::setup(char line[MAX_BUFFER])
	{
		int op;
		sscanf(line," %d %f ",&op,&probability[0]);
		assert(probability[0]>=0);
	}

	Crossover::~Crossover()
	{
		delete [] probability;
	}

	//  Mutation: Sub_operator -------------------------------------------------------------

	Mutation::Mutation():Intra_Operator(1)
	{
		probability = new float[2];
	}

	void Mutation::mutate(Solution& sol) const
	{

            Solution hijo = sol;

            //if(probability[1] <= 0.0) return(0);
            
            int numeroDeMutaciones = 0;
            int indiceGen = 0;
            
            for(int i = 0; i < CANTIDAD_CRUCES; i++)
            {
                for(int j = 0; j < sol.pbm().cruces[i];j++)
                {
                    if (rand01()<=probability[1])
                    {
                        int nuevaDuracion;
                        if (rand_int(0,1)) // suma
                            nuevaDuracion = hijo.var(indiceGen) + 1;
                        else // resta
                            nuevaDuracion = hijo.var(indiceGen) - 1;

                        if ((COTA_MINIMA_DURACION <= nuevaDuracion) && (nuevaDuracion <= COTA_MAXIMA_DURACION))
                        {
                            hijo.var(indiceGen) = nuevaDuracion;
                            numeroDeMutaciones++;
                        }
                    }
                    indiceGen++;
                }
                // mutacion de comienzo de fase
                if (rand01()<=probability[1])
                {
                    int nuevoComienzo;
                        if (rand_int(0,1)) // suma
                        nuevoComienzo = hijo.var(indiceGen) + 1;
                    else // resta
                        nuevoComienzo = hijo.var(indiceGen) - 1;
                    // (cruces[i] * 2) - 1 es la cantidad de fases que tengo en el cruce
                    if ((0 <= nuevoComienzo) && (nuevoComienzo <= ((hijo.pbm().cruces[i] * 2) - 1)))
                    {
                        hijo.var(indiceGen) = nuevoComienzo;
                        numeroDeMutaciones++;
                    }
                }
                indiceGen++;
            }
            

            sol = hijo;
	}

	void Mutation::execute(Rarray<Solution*>& sols) const
	{
		for (int i=0;i<sols.size();i++)
			if(rand01() <= probability[0])	mutate(*sols[i]);
	}

	ostream& operator<< (ostream& os, const Mutation&  mutation)
	{
		os << "Mutation." << " Probability: " << mutation.probability[0]
		   << " Probability1: " << mutation.probability[1]
		   << endl;
		return os;
	}

	void Mutation::setup(char line[MAX_BUFFER])
	{
		int op;
		sscanf(line," %d %f %f ",&op,&probability[0],&probability[1]);
		assert(probability[0]>=0);
		assert(probability[1]>=0);
	}

	void Mutation::RefreshState(const StateCenter& _sc) const
	{
		_sc.set_contents_state_variable("_mutation_probability",(char *)probability,2,sizeof(probability));
	}

	void Mutation::UpdateFromState(const StateCenter& _sc)
	{
		unsigned long nbytes,length;
		_sc.get_contents_state_variable("_mutation_probability",(char *)probability,nbytes,length);
	}

	Mutation::~Mutation()
	{
		delete [] probability;
	}

// StopCondition_1 -------------------------------------------------------------------------------------

	StopCondition_1::StopCondition_1():StopCondition()
	{}

	bool StopCondition_1::EvaluateCondition(const Problem& pbm,const Solver& solver,const SetUpParams& setup)
	{
		return ((int)solver.best_cost_trial() == pbm.largo_cromosoma());
	}

	StopCondition_1::~StopCondition_1()
	{}

	//------------------------------------------------------------------------
	// Specific methods ------------------------------------------------------
	//------------------------------------------------------------------------

	bool terminateQ (const Problem& pbm, const Solver& solver,
			 const SetUpParams& setup)
	{
		StopCondition_1 stop;
		return stop.EvaluateCondition(pbm,solver,setup);
	}
}
#endif

