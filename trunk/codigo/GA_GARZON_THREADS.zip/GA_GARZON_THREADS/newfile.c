void* Population::Evaluate_p(void *data) {

    struct threadData *d = (struct threadData *) data;

    int i = (int) d->id_i;
    Population *p = (Population *) d->p;

    int index = p->_fitness_values[i].index;

    if (p->_fitness_values[i].change) {
        p->_fitness_values[i].change = false;
        p->_fitness_values[i].fitness = p->_parents[index]->fitness();
        p->_evaluations++;
    }


    d->res = p->_fitness_values[i].fitness;
}

void Population::evaluate_parents() {
    double upper_fitness = (infinity() * (-1));
    double lower_fitness = (infinity());
    double current_fitness;
    double cost = 0.0;

    int numberOfThreads = _fitness_values.size();
    pthread_t threads[numberOfThreads];
    int rc;

    struct threadData threadDataArray[numberOfThreads];

    int k;

    for (int i = 0, k = 0; i < _fitness_values.size(); i++, k++) {
        threadDataArray[k].id_i = i;
        threadDataArray[k].id_j = 0;
        threadDataArray[k].p = this;
        threadDataArray[k].res = 0.0;
        rc = pthread_create(&threads[k], NULL, &Population::Evaluate_p, &threadDataArray[k]);
        if (rc) {
            printf("ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    //wait for completion
    void * status;
    for (k = 0; k < numberOfThreads; k++) {
        rc = pthread_join(threads[k], &status);
        if (rc) {
            printf("ERROR; return code from pthread_join() is %d\n", rc);
            exit(-1);
        }
    }

    for (int i = 0; i < _fitness_values.size(); i++) {
        current_fitness = _fitness_values[i].fitness;

        if (current_fitness > upper_fitness) {
            _upper_cost = i;
            upper_fitness = current_fitness;
        }

        if (current_fitness < lower_fitness) {
            _lower_cost = i;
            lower_fitness = current_fitness;
        }

        cost += current_fitness;
    }

    _average_cost = cost / _fitness_values.size();
}

void* Population::Evaluate_o(void *data) {

    struct threadData *d = (struct threadData *) data;

    int i = (int) d->id_i;
    int j = (int) d->id_j;

    Population *p = (Population *) d->p;

    if (p->_fitness_aux[j].change) {
        p->_fitness_aux[j].change = false;
        p->_fitness_aux[j].fitness = p->_offsprings[j - i]->fitness();
        p->_evaluations++;
    }

    d->res = p->_fitness_aux[j].fitness;
}

void Population::evaluate_offsprings() {

    int i = 0;
    if (_setup.combine()) // new individuals selected between current individuals and offsprings
    {
        _fitness_aux = Rarray<struct individual>(_parents.size() + _offsprings.size());
        for (i = 0; i < _parents.size(); i++) {
            _fitness_aux[i] = _fitness_values[i];
        }

        int numberOfThreads = _fitness_values.size();
        pthread_t threads[numberOfThreads];
        int rc;

        struct threadData threadDataArray[numberOfThreads];

        int k;

        for (int j = i, k = 0; (j - i) < _offsprings.size(); j++, k++) {
            _fitness_aux[j].index = j;
            _fitness_aux[j].change = true;
            threadDataArray[k].id_i = i;
            threadDataArray[k].id_j = j;
            threadDataArray[k].p = this;
            threadDataArray[k].res = 0.0;
            rc = pthread_create(&threads[k], NULL, &Population::Evaluate_o, &threadDataArray[k]);
            if (rc) {
                printf("ERROR; return code from pthread_create() is %d\n", rc);
                exit(-1);
            }
        }

        //wait for completion
        void * status;
        for (k = 0; k < numberOfThreads; k++) {
            rc = pthread_join(threads[k], &status);
            if (rc) {
                printf("ERROR; return code from pthread_join() is %d\n", rc);
                exit(-1);
            }
        }

    } else // new individuals selected only between offsprings
    {
        _fitness_aux = Rarray<struct individual>(_offsprings.size());
        for (i = 0; i < _offsprings.size(); i++) {
            _fitness_aux[i].index = i;
            _fitness_aux[i].change = true;
            Evaluate(_offsprings[i], _fitness_aux[i]);
        }
    }
}


