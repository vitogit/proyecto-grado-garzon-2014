#ifndef INC_newGA_mallba_hh
#define INC_newGA_mallba_hh


#include <iostream>
#include <fstream>
#include <math.h>
#include <limits.h>
#include <float.h>
#include <Rlist.h>
#include <Rarray.h>
#include <Messages.h>
#include <mallba.hh>
#include <States.hh>
#include <random.hh>
#include <time.hh>
#include <netstream.hh>
#include <assert.h>

#include "pugixml.hpp"

#include <pthread.h>


#define COTA_MAXIMA_DURACION 60
#define COTA_MINIMA_DURACION 5
#define LARGO_CROMOSOMA 62
#define CANTIDAD_CRUCES 14
#define COTA_SUMA 10
#define SEMAFOROS "/sumo/semaforos-%ld.xml"
#define TEMPLATE_SEMAFOROS "/sumo/templateSemaforos.xml"
#define MEJOR_CONFIGURACION_SERMAFOROS "/sumo/mejorConfiguracionSemaforos.xml"
#define SALIDA_SUMO "/sumo/salidaSumo-%ld.txt"
#define SUMO "/usr/local/bin/sumo"
#define OUT "/sumo/out-%ld.txt"
#define GARZON "/sumo/Garzon.sumocfg"
#define SALIDA_TRIP "/sumo/output_tripinfo-%ld.xml"
#define BUSFLOW_XML "/sumo/Busses.add.xml"
#define DURACION_SIMULACION "600"


using namespace std;
using namespace pugi;



#ifndef _INDIVIDUAL_
#define _INDIVIDUAL_

struct individual // index of a individual in the population and its fitness
{
	int    index;
	double fitness;
	double sel_parameter;
	bool   change;
};

struct threadData {
    int id_i; //Thread number
    int id_j;
    int id_k;
    void *poblacion; //FunciÃ³n que evaluarÃ¡ el thread
    float resultado; //Resultado devuelto
};

/*int lessF(const struct individual &i1,const  struct individual &i2)
{
	return i1.fitness < i2.fitness;
}

int lessS(const struct individual &i1,const  struct individual &i2)
{
	return i1.sel_parameter < i2.sel_parameter;
}

int greaterF(const struct individual &i1,const  struct individual &i2)
{
	return i1.fitness > i2.fitness;
}

int greaterS(const struct individual &i1,const  struct individual &i2)
{
	return i1.sel_parameter > i2.sel_parameter;
}*/
#endif
#endif
